from PyQt6 import QtCore, QtGui, QtWidgets

from PyQt6.QtWidgets import QApplication, QMainWindow, QDialog, QWidget
import sys
from MainWindow import Main_Form
# from Page010_1 import Ui_Page10_1
from Page010_2 import Ui_Page10_2
# from Page011_1 import Ui_Page11_1
from Page011_2 import Ui_scrollArea
from Page011_3 import Ui_Page11_3
from Page012_1 import Ui_Page12_1
from Page01_01 import Ui_Page01_1
from Page01_02 import Ui_Page01_02

from Page03_1 import  Ui_ODKAccountingPage03_01
from Page03_2 import  Ui_ODKAccountingPage03_2
from connection import Database
from PyQt6.QtSql import QSqlTableModel

from Page04_1 import Ui_ODKAccountingPage04_1
from Page04_2 import Ui_ODKAccountingPage04_2
from Page05_1 import Ui_ODKAccountingPage05_1
from Page05_2 import Ui_ODKAccountingPage05_2
from Page06 import Ui_ODKAccountingPage06
from Page07 import Ui_Page07
from Page08 import Ui_Page08
from Page09 import Ui_Page09


class MainWindow(QWidget, Main_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.db = Database()
        self.UiPage01 = Ui_Page01_1()
        self.UiPage02 = Ui_Page01_2()

        self.UiPage03 = Ui_Page03_1()
        self.UiPage04 = Ui_Page03_2()

        self.UiPage05 = Ui_Page04_1()
        self.UiPage06 = Ui_Page04_2()
        self.UiPage07 = Ui_Page05_1()
        self.UiPage08 = Ui_Page05_2()
        self.UiPage09 = Ui_Page06()
        # self.UiPage10 = Ui_Page07()
        self.UiPage11 = Ui_Page08()
        # self.UiPage12 = Ui_Page09()
        # self.UiPage13 = Ui_Page10_1()
        self.UiPage14 = Ui_Page10_2()

        # self.UiPage15 = Ui_Page11_1()
        # self.UiPage16 = Ui_Page11_2()
        self.UiPage17 = Ui_Page11_3()
        # self.UiPage17 = Ui_Page12_1()


        self.button01_3.clicked.connect(self.UiPage01.show)
        self.button01_4.clicked.connect(self.UiPage02.show)

        self.button03_3.clicked.connect(self.UiPage03.show)
        self.button03_4.clicked.connect(self.UiPage04.show)

        self.button04_3.clicked.connect(self.UiPage05.show)
        self.button04_4.clicked.connect(self.UiPage06.show)
        self.button05_3.clicked.connect(self.UiPage07.show)
        self.button05_4.clicked.connect(self.UiPage08.show)
        self.button06_2.clicked.connect(self.UiPage09.show)
        # self.button07_2.clicked.connect(self.UiPage10.show)
        self.button09_2.clicked.connect(self.UiPage11.show)
        # self.button10_3.clicked.connect(self.UiPage12.show)
        # self.button10_4.clicked.connect(self.UiPage13.show)
        self.button11_4.clicked.connect(self.UiPage14.show)
        # self.button11_5.clicked.connect(self.UiPage15.show)
        # self.button11_6.clicked.connect(self.UiPage16.show)
        self.button12_5.clicked.connect(self.UiPage17.show)
        self.button12_6.clicked.connect(self.UiPage04.show)
        self.button12_7.clicked.connect(self.UiPage04.show)
        self.button12_8.clicked.connect(self.UiPage04.show)
        self.dataWarehouses()
    def dataWarehouses(self):

        for row in self.db.data_name_refWarehouses():

            self.UiPage02.comboBoxSklad.addItem(row['name'])

class Ui_Page01_1(QWidget, Ui_Page01_1):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page01_2(QWidget, Ui_Page01_02):
    def __init__(self):
        super().__init__()
        self.setupUi(self)



# class Ui_Page2(QWidget, Ui_Page02):
#     def __init__(self):
#         super().__init__()
#         self.setupUi(self)

class Ui_Page03_1(QWidget, Ui_ODKAccountingPage03_01):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page03_2(QWidget, Ui_ODKAccountingPage03_2):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page04_1(QWidget, Ui_ODKAccountingPage04_1):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page04_2(QWidget, Ui_ODKAccountingPage04_2):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page05_1(QWidget, Ui_ODKAccountingPage05_1):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page05_2(QWidget, Ui_ODKAccountingPage05_2):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page06(QWidget, Ui_ODKAccountingPage06):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page07(QWidget, Ui_Page07):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page08(QWidget, Ui_Page08):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page09(QWidget, Ui_Page09):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

# class Ui_Page10_1(QWidget, Ui_Page10_1):
#     def __init__(self):
#         super().__init__()
#         self.setupUi(self)

class Ui_Page10_2(QWidget, Ui_Page10_2):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

# class Ui_Page11_1(QWidget, Ui_Page11_1):
#     def __init__(self):
#         super().__init__()
#         self.setupUi(self)

class Ui_Page11_2(QWidget, Ui_scrollArea):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page11_3(QWidget, Ui_Page11_3):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

class Ui_Page12_1(QWidget, Ui_Page12_1):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)  # Новый экземпляр QApplication
    window = MainWindow()  # Создаём объект класса ExampleApp
    window.show()  # Показываем окно
    app.exec()  # и запускаем приложение