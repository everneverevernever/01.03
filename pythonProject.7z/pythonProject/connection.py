import pymysql



class Database():
    def __init__(self):
        super(Database, self).__init__()
        self.connection = False
        self.create_connection()
    def create_connection(self):
        try:
            self.connection = pymysql.connect(
                host='localhost',
                port=3306,
                user='root',
                password='',
                database='ODKdatabase',
                cursorclass=pymysql.cursors.DictCursor
             )
            print("Успешное соединение...")
            print("#" * 20)





        except Exception as ex:
            print("Не удалость установить соединение...")
            print(ex)




    def data_name_refWarehouses(self):
        with self.connection.cursor() as cursor:
            select_all_rows = "SELECT name FROM `refWarehouses`"
            cursor.execute(select_all_rows)

            rows = cursor.fetchall()
            return rows
            # for row in rows:
            #     print(row)
            # print("#" * 20)



db = Database()
db.create_connection()


