import pymysql



class Database():
    def __init__(self):
        super(Database, self).__init__()
        self.connection = False
        self.create_connection()
    def create_connection(self):
        try:
            self.connection = pymysql.connect(
                host='127.127.126.50',
                port=3306,
                user='root',
                password='',
                database='dad',
                cursorclass=pymysql.cursors.DictCursor
             )
            print("Успешное соединение...")
            print("#" * 20)





        except Exception as ex:
            print("Не удалость установить соединение...")
            print(ex)




    def data_name_refWarehouses(self):
        with self.connection.cursor() as cursor:
            select_all_rows = "SELECT name FROM `refWarehouses`"
            cursor.execute(select_all_rows)

            rows = cursor.fetchall()
            for row in rows:
                print(row)
            print("#" * 20)



db = Database()
db.create_connection()

